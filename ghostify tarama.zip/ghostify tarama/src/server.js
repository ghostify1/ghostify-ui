import http from 'http';
import handler from '../api/scan-email.js';

const server = http.createServer((req, res) => {
  if (req.method === 'POST' && req.url === '/api/scan/email') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', async () => {
      try {
        req.body = JSON.parse(body || '{}');
        await handler(req, res);
      } catch {
        res.writeHead(400);
        res.end('Invalid request');
      }
    });
  } else {
    res.writeHead(404);
    res.end('Not found');
  }
});

server.listen(process.env.PORT || 8080, () => {
  console.log('Local up on', process.env.PORT || 8080);
});
