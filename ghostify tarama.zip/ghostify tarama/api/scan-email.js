const { z } = require('zod');

const BodySchema = z.object({ email: z.string().email() });

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Only POST' });
  const parsed = BodySchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Geçersiz e-posta' });

  const email = parsed.data.email;
  try {
    const [hibp, leak] = await Promise.all([
      hibpBreaches(email, process.env.HIBP_API_KEY).catch(e => ({ error: e.message })),
      leakcheckSearch(email, process.env.LEAKCHECK_API_KEY).catch(e => ({ error: e.message }))
    ]);

    return res.status(200).json({
      email,
      hibp: Array.isArray(hibp) ? { count: hibp.length, breaches: hibp.map(b => b.Name) } : { error: hibp.error },
      leakcheck: leak.error ? { error: leak.error } : { count: leak.total },
      time: new Date().toISOString()
    });
  } catch (e) {
    return res.status(502).json({ error: 'Upstream', detail: String(e) });
  }
}
